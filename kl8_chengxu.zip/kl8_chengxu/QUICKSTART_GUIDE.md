# 快速启动指南

## 🚀 一键启动（推荐）

### macOS/Linux
```bash
cd /Users/luluzhenlan/PycharmProjects/KL8
./start_all.sh
```

### Windows
```cmd
cd C:\Users\luluzhenlan\PycharmProjects\KL8
start_all.bat
```

## 📝 手动启动

### 第一步：启动后端

```bash
cd kl8_chengxu
pip install -r requirements_api.txt
python kl8_api_server.py
```

后端将在 `http://localhost:8000` 运行

### 第二步：启动前端

1. 打开微信开发者工具
2. 选择"导入项目"
3. 选择 `kl8 2` 文件夹
4. 点击"编译"按钮

## 🧪 测试后端

启动后端后，运行测试脚本：

```bash
./test_backend.sh
```

或直接访问：
- 健康检查：http://localhost:8000/api/health
- 期数列表：http://localhost:8000/api/lottery/periods

## 📱 小程序配置

### 开发环境
无需额外配置，前端默认连接 `http://localhost:8000`

### 真机调试
需要在微信公众平台配置服务器域名白名单

## 🔧 常见问题

### Q: 后端启动失败
**A:** 检查 Python 版本（需要 3.7+），安装依赖：`pip install -r kl8_chengxu/requirements_api.txt`

### Q: 前端无法连接后端
**A:**
1. 确认后端是否正常运行（访问 http://localhost:8000/api/health）
2. 检查 `kl8 2/config.js` 中的 `baseURL` 配置
3. 开发工具中勾选"不校验合法域名"

### Q: 数据为空
**A:** 后端首次启动需要时间获取数据，请等待 1-2 分钟，或访问 http://localhost:8000/api/prediction/generate 手动触发更新

## 📚 详细文档

- 后端 API 文档：`kl8_chengxu/API_README.md`
- 前后端对接说明：`kl8 2/FRONTEND_API_README.md`
